import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer

# =================================================
# PAGE CONFIG
# =================================================
st.set_page_config(page_title="Mental Health Risk Predictor", layout="wide")
st.title("🧠 Mental Health Risk Prediction System")

# =================================================
# LOAD DATASET
# =================================================
@st.cache_data
def load_data():
    return pd.read_csv(r"D:\reg\reg_data.csv")

df = load_data()

# =================================================
# LIKERT SCALE MAPPING
# =================================================
likert_map = {
    "Never": 1, "Rarely": 2, "Sometimes": 3, "Often": 4, "Always": 5
}

likert_cols = [
    c for c in df.columns
    if any(k in c.lower() for k in
           ["sleep", "anx", "stress", "depress", "concentrat", "exhaust"])
]

df[likert_cols] = df[likert_cols].replace(likert_map)

# =================================================
# FEATURE ENGINEERING
# =================================================
df["Mental_Health_Score"] = df[likert_cols].sum(axis=1)

sleep_cols = [c for c in likert_cols if "sleep" in c.lower()]
df["Sleep_Score"] = df[sleep_cols].mean(axis=1)

emotional_cols = [c for c in likert_cols if any(
    k in c.lower() for k in ["anx", "stress", "depress", "concentrat", "exhaust"]
)]
df["Emotional_State_Score"] = df[emotional_cols].mean(axis=1)

# =================================================
# RANDOM FOREST MODEL
# =================================================
X = df[["Sleep_Score", "Emotional_State_Score"]]
y = df["Mental_Health_Score"]

imputer = SimpleImputer(strategy="mean")
X_imputed = imputer.fit_transform(X)

model = RandomForestRegressor(
    n_estimators=300,
    max_depth=6,
    random_state=42
)
model.fit(X_imputed, y)

# =================================================
# RISK FUNCTION (RULE-BASED, EXPLAINABLE)
# =================================================
def compute_risk(sleep_hours, emotional_score, phone_after_10):
    base = 4.5
    sleep_effect = (7 - sleep_hours) * 0.6
    emotion_effect = (emotional_score - 3) * 1.2
    phone_effect = 0.8 if phone_after_10 else 0
    return float(np.clip(base + sleep_effect + emotion_effect + phone_effect, 0, 10))

# =================================================
# USER INPUT
# =================================================
st.subheader("🧍 Lifestyle Input")

col1, col2 = st.columns(2)

with col1:
    sleep_hours = st.slider("Hours slept last night", 4.0, 9.0, 6.5, 0.5)

with col2:
    used_after_10 = st.radio("Used mobile after 10 PM?", ["No", "Yes"])

anxious = st.slider("Feeling anxious", 1.0, 5.0, 3.0, 0.5)
stressed = st.slider("Feeling stressed", 1.0, 5.0, 3.0, 0.5)
exhausted = st.slider("Feeling mentally exhausted", 1.0, 5.0, 3.0, 0.5)
concentrate = st.slider("Difficulty concentrating", 1.0, 5.0, 3.0, 0.5)
depressed = st.slider("Feeling low or depressed", 1.0, 5.0, 3.0, 0.5)

emotional_score = np.mean([
    anxious, stressed, exhausted, concentrate, depressed
])

# =================================================
# CURRENT RISK
# =================================================
base_risk = compute_risk(
    sleep_hours,
    emotional_score,
    used_after_10 == "Yes"
)

st.subheader("🧠 Current Risk")
st.metric("Risk Score", f"{base_risk:.2f} / 10")

# =================================================
# WHAT-IF SIMULATION
# =================================================
st.subheader("🔁 Predicted Risk After Improvement")

add_sleep = st.slider("Increase sleep (hours)", 0.0, 3.0, 1.0, 0.5)
reduce_emotion = st.slider("Reduce emotional stress (points)", 0.0, 2.0, 1.0, 0.5)

sim_risk = compute_risk(
    sleep_hours + add_sleep,
    emotional_score - reduce_emotion,
    used_after_10 == "Yes"
)

risk_difference = sim_risk - base_risk

st.metric(
    "Risk Change (Simulation – Current)",
    f"{risk_difference:+.2f}"
)

# =================================================
# VISUALIZATION
# =================================================
st.subheader("📈 Visual Analysis")

colA, colB = st.columns(2)

# ---------- SCATTER + MODEL TREND ----------
with colA:
    fig1, ax1 = plt.subplots(figsize=(6, 4))

    ax1.scatter(df["Sleep_Score"], y, alpha=0.4, label="Dataset")

    # Convert hours → Likert-style sleep score
    user_sleep_score = np.clip((sleep_hours / 9) * 5, 1, 5)

    ax1.scatter(
        user_sleep_score,
        base_risk * (y.max() / 10),
        s=90,
        label="Your Input"
    )

    x_vals = np.linspace(df["Sleep_Score"].min(), df["Sleep_Score"].max(), 100)
    mean_emotion = df["Emotional_State_Score"].mean()

    X_line = pd.DataFrame({
        "Sleep_Score": x_vals,
        "Emotional_State_Score": mean_emotion
    })

    y_line = model.predict(imputer.transform(X_line))
    ax1.plot(x_vals, y_line, linewidth=2, label="Random Forest Trend")

    ax1.set_xlabel("Sleep Score (Likert Scale)")
    ax1.set_ylabel("Mental Health Score")
    ax1.legend()
    st.pyplot(fig1)

# ---------- RISK BAR ----------
with colB:
    fig2, ax2 = plt.subplots(figsize=(6, 4))
    ax2.bar(
        ["Current Risk", "After Improvement"],
        [base_risk, sim_risk]
    )
    ax2.set_ylabel("Risk Score (0–10)")
    ax2.set_title("Risk Comparison")
    st.pyplot(fig2)

# =================================================
# FEATURE IMPORTANCE
# =================================================
st.subheader("🧩 Feature Contribution Analysis")

importance = model.feature_importances_
features = ["Sleep Score", "Emotional State Score"]

fig3, ax3 = plt.subplots(figsize=(6, 4))
ax3.bar(features, importance)
ax3.set_ylabel("Importance Weight")
ax3.set_title("Impact on Mental Health Score")
st.pyplot(fig3)

# =================================================
# EXPLANATION
# =================================================
st.markdown("### 📝 Risk Change Description")

st.write(f"Current risk score: **{base_risk:.2f} / 10**")
st.write(
    f"After improving sleep by **{add_sleep} hour(s)** and reducing emotional "
    f"stress by **{reduce_emotion} point(s)**, risk becomes **{sim_risk:.2f} / 10**."
)

if risk_difference < 0:
    st.success(
        f"Risk reduced by **{abs(risk_difference):.2f} points**, showing a "
        "**positive mental health improvement**."
    )
elif risk_difference > 0:
    st.warning(
        f"Risk increased by **{risk_difference:.2f} points**."
    )
else:
    st.info("No measurable change in risk.")

st.caption("⚠️ Educational purpose only. Not a clinical diagnosis.")
