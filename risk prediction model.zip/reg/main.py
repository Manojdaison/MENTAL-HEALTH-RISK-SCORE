import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer

# =================================================
# PAGE CONFIG
# =================================================
st.set_page_config(page_title="Mental Health Risk Prediction", layout="wide")
st.title("🧠 Mental Health Risk Prediction & Simulation System")

# =================================================
# LOAD DATASET
# =================================================
@st.cache_data
def load_data():
    return pd.read_csv(r"D:\reg\reg_data.csv")

df = load_data()

# =================================================
# LIKERT SCALE MAPPING
# =================================================
likert_map = {
    "Never": 1,
    "Rarely": 2,
    "Sometimes": 3,
    "Often": 4,
    "Always": 5
}

likert_cols = [
    col for col in df.columns
    if any(k in col.lower() for k in [
        "sleep", "anx", "stress", "depress", "concentrat"
    ])
]

df[likert_cols] = df[likert_cols].replace(likert_map)

# =================================================
# TARGET VARIABLE
# =================================================
df["Mental_Health_Score"] = df[likert_cols].sum(axis=1)

# =================================================
# FEATURE ENGINEERING (DATASET SIDE)
# =================================================
sleep_cols = [c for c in likert_cols if "sleep" in c.lower()]
df["Sleep_Score"] = df[sleep_cols].mean(axis=1)

emotional_cols = [c for c in likert_cols if any(
    k in c.lower() for k in ["anx", "stress", "depress", "concentrat"]
)]
df["Emotional_State_Score"] = df[emotional_cols].mean(axis=1)

# =================================================
# REGRESSION MODEL (DATASET BASED)
# =================================================
feature_cols = ["Sleep_Score", "Emotional_State_Score"]
X = df[feature_cols]
y = df["Mental_Health_Score"]

imputer = SimpleImputer(strategy="mean")
X_imputed = imputer.fit_transform(X)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_imputed)

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

st.subheader("📈 Model Performance")
st.write("**Regression R² Score:**", round(model.score(X_test, y_test), 3))

# =================================================
# USER INPUT SECTION
# =================================================
st.subheader("🧍 Real-Time User Input")

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("### 📱 Phone Usage")
    daily_hours = st.slider("Daily phone usage (hours)", 0.0, 12.0, 5.0)
    after_10 = st.selectbox("Phone usage after 10 PM?", ["No", "Yes"])
    platforms = st.slider("Number of social media platforms used", 1, 10, 4)

with col2:
    st.markdown("### 😴 Sleep")
    sleep_hours = st.slider("Average sleep hours per day", 3.0, 10.0, 6.5)
    sleep_difficulty = st.slider("Difficulty falling asleep (1–5)", 1, 5, 3)

with col3:
    st.markdown("### 😟 Emotional State")
    anxious = st.slider("Feeling anxious (1–5)", 1, 5, 3)
    stressed = st.slider("Feeling stressed (1–5)", 1, 5, 3)
    exhausted = st.slider("Feeling mentally exhausted (1–5)", 1, 5, 3)
    concentrate = st.slider("Difficulty concentrating (1–5)", 1, 5, 3)
    depressed = st.slider("Feeling low or depressed (1–5)", 1, 5, 3)

# =================================================
# SCORE CALCULATION
# =================================================
phone_score = (daily_hours + (1 if after_10 == "Yes" else 0) + platforms) / 3
sleep_score = (sleep_hours + sleep_difficulty) / 2
emotional_score = np.mean([anxious, stressed, exhausted, concentrate, depressed])

student_df = pd.DataFrame([[sleep_score, emotional_score]], columns=feature_cols)
student_scaled = scaler.transform(imputer.transform(student_df))
predicted_score = model.predict(student_scaled)[0]

# =================================================
# RISK INTERPRETATION
# =================================================
def risk_label(score):
    if score < 15:
        return "🟢 LOW RISK"
    elif score < 25:
        return "🟠 MODERATE RISK"
    else:
        return "🔴 HIGH RISK"

st.subheader("🧠 Prediction Result")
st.metric("Predicted Mental Health Score", round(predicted_score, 2))
st.write("**Risk Level:**", risk_label(predicted_score))

# =================================================
# EXPLAINABLE INSIGHTS
# =================================================
st.subheader("🔍 Personalized Insight")

coef_sleep, coef_emotion = model.coef_

dominant = "Sleep Pattern" if abs(coef_sleep) > abs(coef_emotion) else "Emotional State"
st.write(f"**Dominant Risk Contributor:** {dominant}")

st.write({
    "Sleep Impact": round(coef_sleep, 3),
    "Emotional Impact": round(coef_emotion, 3)
})

# =================================================
# WHAT-IF SIMULATION
# =================================================
st.subheader("🔁 What-If Simulation")

improve_sleep = st.slider("Increase sleep hours by", 0.0, 3.0, 1.0)
reduce_emotion = st.slider("Reduce emotional stress by", 0.0, 2.0, 1.0)

sim_sleep = sleep_score + improve_sleep
sim_emotion = max(1, emotional_score - reduce_emotion)

sim_df = pd.DataFrame([[sim_sleep, sim_emotion]], columns=feature_cols)
sim_scaled = scaler.transform(imputer.transform(sim_df))
sim_score = model.predict(sim_scaled)[0]

st.metric(
    "Predicted Score After Improvement",
    round(sim_score, 2),
    delta=round(sim_score - predicted_score, 2)
)

# =================================================
# RISK CONTRIBUTION %
# =================================================
st.subheader("📊 Risk Contribution (%)")

total = abs(coef_sleep) + abs(coef_emotion)
sleep_pct = (abs(coef_sleep) / total) * 100
emotion_pct = (abs(coef_emotion) / total) * 100

contrib_df = pd.DataFrame({
    "Factor": ["Sleep Pattern", "Emotional State"],
    "Contribution (%)": [sleep_pct, emotion_pct]
})

st.bar_chart(contrib_df.set_index("Factor"))

# =================================================
# SMART RECOMMENDATIONS
# =================================================
st.subheader("💡 Data-Driven Recommendations")

if sleep_pct > emotion_pct:
    st.write("✔ Improve sleep duration and quality.")
    st.write("✔ Avoid phone usage before bedtime.")
else:
    st.write("✔ Practice stress management techniques.")
    st.write("✔ Reduce continuous screen exposure.")

# =================================================
# REGRESSION VISUALIZATION
# =================================================
st.subheader("📊 Regression Analysis")

fig, axes = plt.subplots(1, 2, figsize=(12, 4))

for ax, feature in zip(axes, feature_cols):
    ax.scatter(df[feature], y, alpha=0.5)

    x_vals = np.linspace(df[feature].min(), df[feature].max(), 100)
    means = df[feature_cols].mean()

    if feature == "Sleep_Score":
        X_line = pd.DataFrame({
            "Sleep_Score": x_vals,
            "Emotional_State_Score": means["Emotional_State_Score"]
        })
    else:
        X_line = pd.DataFrame({
            "Sleep_Score": means["Sleep_Score"],
            "Emotional_State_Score": x_vals
        })

    y_line = model.predict(
        scaler.transform(imputer.transform(X_line))
    )

    ax.plot(x_vals, y_line, color="red")
    ax.set_xlabel(feature)
    ax.set_ylabel("Mental Health Score")
    ax.set_title(f"{feature} vs Risk")

st.pyplot(fig)

# =================================================
# PROJECT SUMMARY
# =================================================
st.subheader("📘 Project Summary")

st.markdown("""
**Objective:**  
To predict and analyze mental health risk using regression models based on sleep and emotional behavior.

**Key Features:**  
- Regression-based prediction  
- Explainable insights  
- What-if simulation  
- Risk contribution analysis  
- Data-driven recommendations  

**Outcome:**  
An interactive decision-support system for mental well-being.
""")
