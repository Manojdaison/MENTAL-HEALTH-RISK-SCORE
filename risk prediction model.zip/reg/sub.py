import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer

# =================================================
# 1. LOAD DATASET
# =================================================
df = pd.read_csv(r"D:\reg\reg_data.csv")

# =================================================
# 2. LIKERT SCALE MAPPING
# =================================================
likert_map = {
    "Never": 1,
    "Rarely": 2,
    "Sometimes": 3,
    "Often": 4,
    "Always": 5
}

likert_cols = [
    col for col in df.columns
    if any(k in col.lower() for k in [
        "anx", "stress", "depress", "concentrat", "sleep"
    ])
]

df[likert_cols] = df[likert_cols].replace(likert_map)

# =================================================
# 3. TARGET VARIABLE (MENTAL HEALTH SCORE)
# =================================================
df["Mental_Health_Score"] = df[likert_cols].sum(axis=1)

# =================================================
# 4. FEATURE ENGINEERING (DATASET SIDE)
# =================================================

# --- PHONE USAGE SCORE ---
phone_numeric_cols = df.filter(regex="phone|hour", axis=1).select_dtypes(include=np.number).columns
df["Phone_Usage_Score"] = df[phone_numeric_cols].mean(axis=1)

# --- SLEEP SCORE ---
sleep_cols = [c for c in likert_cols if "sleep" in c.lower()]
df["Sleep_Score"] = df[sleep_cols].mean(axis=1)

# --- EMOTIONAL STATE SCORE ---
emotional_cols = [c for c in likert_cols if any(
    k in c.lower() for k in ["anx", "stress", "depress", "concentrat"]
)]
df["Emotional_State_Score"] = df[emotional_cols].mean(axis=1)

# =================================================
# 5. REGRESSION FEATURES (DATASET-SAFE)
# =================================================

# Phone usage is NOT available historically → exclude from training
feature_cols = [
    "Sleep_Score",
    "Emotional_State_Score"
]

X = df[feature_cols]
y = df["Mental_Health_Score"]

print("\nRegression Features Used (Dataset):")
for f in feature_cols:
    print(" -", f)

# =================================================
# 6. HANDLE MISSING VALUES + TRAIN REGRESSION MODEL
# =================================================

imputer = SimpleImputer(strategy="mean")
X_imputed = imputer.fit_transform(X)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_imputed)

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)

print("\nRegression R² Score:", round(model.score(X_test, y_test), 3))

# =================================================
# 7. REAL-TIME STUDENT INTERACTION
# =================================================
print("\n--- REAL-TIME MENTAL HEALTH ANALYSIS ---")

# Phone usage (used only for interpretation, not training)
daily_hours = float(input("Daily phone usage (hours): "))
after_10 = int(input("Phone usage after 10 PM? (1=No, 2=Yes): "))
platforms = int(input("Number of social media platforms used: "))

phone_score = (daily_hours + after_10 + platforms) / 3

# Sleep
sleep_hours = float(input("Average sleep hours per day: "))
sleep_difficulty = int(input("Difficulty falling asleep (1–5): "))
sleep_score = (sleep_hours + sleep_difficulty) / 2

# Emotional state
emotional_questions = [
    "Feeling anxious",
    "Feeling stressed",
    "Feeling mentally exhausted",
    "Difficulty concentrating",
    "Feeling low or depressed"
]

emotional_values = [int(input(f"{q} (1–5): ")) for q in emotional_questions]
emotional_score = np.mean(emotional_values)

student_df = pd.DataFrame([[sleep_score, emotional_score]],
                          columns=feature_cols)

student_imputed = imputer.transform(student_df)
student_scaled = scaler.transform(student_imputed)

predicted_score = model.predict(student_scaled)[0]

print("\nPredicted Mental Health Score:", round(predicted_score, 2))

# =================================================
# 8. RISK INTERPRETATION
# =================================================
def risk_label(score):
    if score < 15:
        return "LOW RISK"
    elif score < 25:
        return "MODERATE RISK"
    else:
        return "HIGH RISK"

print("Predicted Risk Level:", risk_label(predicted_score))

## =================================================
# 9. SCATTER PLOTS WITH REGRESSION LINE (STABLE)
# =================================================
plt.figure(figsize=(12, 4))

for i, feature in enumerate(feature_cols, 1):
    plt.subplot(1, 2, i)
    plt.scatter(df[feature], y, alpha=0.5, label="Data")

    # Regression line using trained model
    x_vals = np.linspace(df[feature].min(), df[feature].max(), 100)
    other_feature_mean = df[feature_cols].mean()

    if feature == "Sleep_Score":
        X_line = pd.DataFrame({
            "Sleep_Score": x_vals,
            "Emotional_State_Score": other_feature_mean["Emotional_State_Score"]
        })
    else:
        X_line = pd.DataFrame({
            "Sleep_Score": other_feature_mean["Sleep_Score"],
            "Emotional_State_Score": x_vals
        })

    X_line_scaled = scaler.transform(imputer.transform(X_line))
    y_line = model.predict(X_line_scaled)

    plt.plot(x_vals, y_line, label="Regression Line")
    plt.xlabel(feature)
    plt.ylabel("Mental Health Score")
    plt.legend()
    plt.title(f"{feature} vs Mental Health Risk")

plt.tight_layout()
plt.show()
