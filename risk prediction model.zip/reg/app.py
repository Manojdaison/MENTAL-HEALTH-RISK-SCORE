import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

# =================================================
# PAGE CONFIG
# =================================================
st.set_page_config(page_title="Mental Health Risk Predictor", layout="wide")
st.title("🧠 Mental Health Risk Prediction System")

# =================================================
# LOAD DATASET
# =================================================
@st.cache_data
def load_data():
    return pd.read_csv(r"D:\reg\reg_data.csv")

df = load_data()

# =================================================
# LIKERT SCALE MAPPING
# =================================================
likert_map = {
    "Never": 1, "Rarely": 2, "Sometimes": 3, "Often": 4, "Always": 5
}

likert_cols = [
    c for c in df.columns
    if any(k in c.lower() for k in ["sleep", "anx", "stress", "depress", "concentrat"])
]

df[likert_cols] = df[likert_cols].replace(likert_map)

df["Mental_Health_Score"] = df[likert_cols].sum(axis=1)

sleep_cols = [c for c in likert_cols if "sleep" in c.lower()]
df["Sleep_Score"] = df[sleep_cols].mean(axis=1)

emotional_cols = [c for c in likert_cols if any(
    k in c.lower() for k in ["anx", "stress", "depress", "concentrat"]
)]
df["Emotional_State_Score"] = df[emotional_cols].mean(axis=1)

# =================================================
# REGRESSION MODEL (UNCHANGED)
# =================================================
X = df[["Sleep_Score", "Emotional_State_Score"]]
y = df["Mental_Health_Score"]

imputer = SimpleImputer(strategy="mean")
scaler = StandardScaler()
X_scaled = scaler.fit_transform(imputer.fit_transform(X))
model = LinearRegression().fit(X_scaled, y)

# =================================================
# RISK FUNCTION (UNCHANGED)
# =================================================
def compute_risk(sleep_hours, emotional_score, phone_after_10):
    base = 4.5
    sleep_effect = (7 - sleep_hours) * 0.6
    emotion_effect = (emotional_score - 3) * 1.2
    phone_effect = 0.8 if phone_after_10 else 0
    return float(np.clip(base + sleep_effect + emotion_effect + phone_effect, 0, 10))

# =================================================
# USER INPUT (UNCHANGED)
# =================================================
st.subheader("🧍 Lifestyle Input")

col1, col2 = st.columns(2)

with col1:
    sleep_hours = st.slider("Hours slept last night", 4.0, 9.0, 6.5, 0.5)

with col2:
    used_after_10 = st.radio("Used mobile after 10 PM?", ["No", "Yes"])

anxious = st.slider("Feeling anxious", 1.0, 5.0, 3.0, 0.5)
stressed = st.slider("Feeling stressed", 1.0, 5.0, 3.0, 0.5)
exhausted = st.slider("Feeling mentally exhausted", 1.0, 5.0, 3.0, 0.5)
concentrate = st.slider("Difficulty concentrating", 1.0, 5.0, 3.0, 0.5)
depressed = st.slider("Feeling low or depressed", 1.0, 5.0, 3.0, 0.5)

emotional_score = np.mean([anxious, stressed, exhausted, concentrate, depressed])

# =================================================
# BASE RISK
# =================================================
base_risk = compute_risk(
    sleep_hours,
    emotional_score,
    used_after_10 == "Yes"
)

st.subheader("🧠 Current Risk")
st.metric("Risk Score", f"{base_risk:.2f} / 10")

# =================================================
# WHAT-IF SIMULATION
# =================================================
st.subheader("🔁 Predicted Risk After Improvement")

add_sleep = st.slider("Increase sleep (hours)", 0.0, 3.0, 1.0, 0.5)
reduce_emotion = st.slider("Reduce emotional stress (points)", 0.0, 2.0, 1.0, 0.5)

sim_risk = compute_risk(
    sleep_hours + add_sleep,
    emotional_score - reduce_emotion,
    used_after_10 == "Yes"
)

# =================================================
# NEGATIVE DIFFERENCE (YOUR MODEL)
# =================================================
risk_difference = sim_risk - base_risk   # improvement → NEGATIVE

st.metric(
    "Risk Change (Simulation – Current)",
    f"{risk_difference:+.2f}"
)

# =================================================
# VISUALIZATION
# =================================================
st.subheader("📈 Visual Analysis")

colA, colB = st.columns(2)

# ---------- SCATTER + REGRESSION (UNCHANGED) ----------
with colA:
    fig1, ax1 = plt.subplots(figsize=(6, 4))
    ax1.scatter(df["Sleep_Score"], y, alpha=0.4, label="Dataset")

    ax1.scatter(
        (7 - sleep_hours),
        base_risk * (y.max() / 10),
        color="red",
        s=80,
        label="Your Input"
    )

    x_vals = np.linspace(df["Sleep_Score"].min(), df["Sleep_Score"].max(), 100)
    mean_emotion = df["Emotional_State_Score"].mean()

    X_line = pd.DataFrame({
        "Sleep_Score": x_vals,
        "Emotional_State_Score": mean_emotion
    })

    y_line = model.predict(scaler.transform(imputer.transform(X_line)))
    ax1.plot(x_vals, y_line, color="black", linewidth=2, label="Regression Line")

    ax1.set_xlabel("Sleep Score")
    ax1.set_ylabel("Mental Health Score")
    ax1.legend()
    st.pyplot(fig1)

# ---------- PREVIOUS BAR CHART (KEPT, LOGIC FIXED) ----------
with colB:
    fig2, ax2 = plt.subplots(figsize=(6, 4))

    ax2.bar(
        ["Current Risk", "After Improvement"],
        [base_risk, base_risk + risk_difference],  # subtraction applied
        color=["orange", "green"]
    )

    ax2.set_ylabel("Risk Score (0–10)")
    ax2.set_title("Risk Comparison (Improvement as Reduction)")
    st.pyplot(fig2)

st.markdown("### 📝 Risk Change Description")

st.write(
    f"Based on the current inputs, the predicted mental health risk score is "
    f"**{base_risk:.2f} / 10**."
)

st.write(
    f"After applying the selected improvements (sleep increase of **{add_sleep} hour(s)** "
    f"and emotional stress reduction of **{reduce_emotion} point(s)**), "
    f"the simulated risk score becomes **{sim_risk:.2f} / 10**."
)

st.write(
    "The change in risk is calculated using the formula:"
)

st.code("Risk Difference = Simulated Risk − Current Risk")

# Dynamic interpretation
if risk_difference < 0:
    st.success(
        f"The risk difference is **{risk_difference:.2f}**, which is a **negative value**. "
        "This indicates a **reduction in mental health risk**, meaning the applied lifestyle "
        "changes have positively improved the predicted mental health condition."
    )

elif risk_difference > 0:
    st.warning(
        f"The risk difference is **+{risk_difference:.2f}**, which is a **positive value**. "
        "This indicates an **increase in mental health risk**, suggesting that the current "
        "changes are insufficient or counterproductive."
    )

else:
    st.info(
        "The risk difference is **0.00**, indicating **no measurable change** in the predicted "
        "mental health risk after simulation."
    )

st.write(
    "In the comparison bar chart, the **After Improvement** bar being lower than the "
    "**Current Risk** bar visually confirms a reduction in risk."
)